#!/bin/sh
sudo service tomcat8 stop